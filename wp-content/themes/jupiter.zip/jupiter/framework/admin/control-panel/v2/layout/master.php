<div class="mka-cp-wrap mka-wrap" id="js__mka-cp-wrap">

	<?php include_once('header.php'); ?>

	<div class="mka-cp-container">
		<?php include_once('sidebar.php'); ?>
		<div class="mka-cp-panes" id="js__mka-cp-panes">
				<?php include_once(THEME_CONTROL_PANEL . '/v2/panes/support.php'); ?>
		</div>
	</div>
</div>

